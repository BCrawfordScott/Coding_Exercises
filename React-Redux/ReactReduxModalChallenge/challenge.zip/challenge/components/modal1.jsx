const Modal1 = (props) => {
  return(
    <div>I'm the first modal!</div>
  );
};

export default modal1;
