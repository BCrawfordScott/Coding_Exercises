const Modal3 = (props) => {
  return(
    <div>I'm the third modal!</div>
  );
};

export default modal3;
