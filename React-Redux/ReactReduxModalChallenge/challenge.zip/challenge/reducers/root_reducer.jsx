import uiReducer from './uiReducer';

export default combineReducers(
  {
    ui: uiReducer
  }
);
