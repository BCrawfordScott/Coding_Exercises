import {
  OPEN_MODAL,
  CLOSE_MODAL
} from '../actions/ui_actions';

const uiReducer = (state, action) => {

};

export default uiReducer;
