# Solution

It's recommended that you look through each piece of the solution.  There are notes
highlighting important areas to focus on and take note of.
