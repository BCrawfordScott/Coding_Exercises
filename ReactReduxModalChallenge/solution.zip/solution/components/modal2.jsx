const Modal2 = (props) => {
  return(
    <div>I'm the second modal!</div>
  );
};

export default modal2;
