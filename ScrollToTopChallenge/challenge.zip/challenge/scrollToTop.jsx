import React from 'react';
import { withRouter } from 'react-router';

class ScrollToTop extends React.Component {


  render() {
  }
}

export default withRouter(ScrollToTop);
